<?php


function filter_book_content($content){
     
    return $content;
}