# wp_book_lib
wp_book_lib  is a  plugin that  will permit  wordpress users to  create a  fully  working  book  lib  in which  book  authors  can  create and edite  thier  books , made  by  Mfou'ou medjo  stanly 
