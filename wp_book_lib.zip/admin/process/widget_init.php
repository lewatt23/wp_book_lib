<?php


function wp_book_init_widgets(){
    register_widget('WBL_DAILY_BOOk');
}